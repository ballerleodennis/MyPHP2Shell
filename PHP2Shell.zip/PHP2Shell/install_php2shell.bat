@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul
title php2shell Installer
color 0A

set "REPO=https://github.com/murrez/php2shell.git"
set "INSTALL_DIR=%~1"
if "%INSTALL_DIR%"=="" set "INSTALL_DIR=%USERPROFILE%\php2shell"
set "TMPPY=%TEMP%\php2shell_py.txt"
if exist "%TMPPY%" del /q "%TMPPY%" >nul 2>&1

echo ============================================================
echo   php2shell - vollstaendige Installation
echo   Ziel: %INSTALL_DIR%
echo ============================================================
echo.

rem ---------- 1. Python 3.8+ pruefen / installieren ----------
echo [1/6] Pruefe Python 3.8+ ...
call :find_python
if errorlevel 1 (
    echo    Python fehlt oder ist zu alt. Versuche Installation via winget ...
    where winget >nul 2>&1
    if errorlevel 1 goto :python_direct
    winget install --id Python.Python.3.12 -e --source winget --accept-package-agreements --accept-source-agreements --silent --disable-interactivity
    call :refresh_path
    call :find_python
    if errorlevel 1 goto :python_direct
)
goto :python_ok

:python_direct
echo    Lade Python-Installer direkt von python.org ...
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.12.7/python-3.12.7-amd64.exe' -OutFile '%TEMP%\python_setup.exe' -UseBasicParsing; exit 0 } catch { exit 1 }"
if errorlevel 1 (
    echo    FEHLER: Download von Python fehlgeschlagen.
    echo    Bitte manuell installieren: https://www.python.org/downloads/
    goto :fail
)
echo    Installiere Python (silent) ...
"%TEMP%\python_setup.exe" /quiet InstallAllUsers=0 PrependPath=1 Include_pip=1 Include_test=0
timeout /t 5 /nobreak >nul
call :refresh_path
call :find_python
if errorlevel 1 (
    echo    FEHLER: Python konnte nicht bereitgestellt werden.
    goto :fail
)

:python_ok
set /p PYEXE=<"%TMPPY%"
if not defined PYEXE (
    echo    FEHLER: Python-Pfad konnte nicht ermittelt werden.
    goto :fail
)
echo    Python gefunden: !PYEXE!
echo.

rem ---------- 2. Git pruefen / installieren ----------
echo [2/6] Pruefe Git ...
where git >nul 2>&1
if errorlevel 1 (
    echo    Git fehlt. Versuche Installation via winget ...
    where winget >nul 2>&1
    if errorlevel 1 (
        echo    FEHLER: Git fehlt und winget ist nicht verfuegbar.
        echo    Bitte manuell installieren: https://git-scm.com/download/win
        goto :fail
    )
    winget install --id Git.Git -e --source winget --accept-package-agreements --accept-source-agreements --silent --disable-interactivity
    call :refresh_path
)
where git >nul 2>&1
if errorlevel 1 (
    echo    FEHLER: Git ist nach der Installation nicht auffindbar.
    echo    Terminal neu starten und Skript erneut ausfuehren.
    goto :fail
)
echo    Git bereit.
echo.

rem ---------- 3. Repo holen ----------
echo [3/6] Hole Repository ...
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
if exist "%INSTALL_DIR%\.git" (
    pushd "%INSTALL_DIR%"
    git pull --ff-only
    popd
) else (
    git clone "%REPO%" "%INSTALL_DIR%"
    if errorlevel 1 (
        echo    FEHLER: Clone fehlgeschlagen.
        goto :fail
    )
)
if not exist "%INSTALL_DIR%\poc.py" (
    echo    FEHLER: poc.py nicht gefunden - Repo unvollstaendig.
    goto :fail
)
echo    Repository bereit.
echo.

rem ---------- 4. Virtuelle Umgebung ----------
echo [4/6] Erstelle virtuelle Umgebung ...
if not exist "%INSTALL_DIR%\.venv" (
    "!PYEXE!" -m venv "%INSTALL_DIR%\.venv"
    if errorlevel 1 (
        echo    FEHLER: venv-Erstellung fehlgeschlagen.
        goto :fail
    )
)
set "VPY=%INSTALL_DIR%\.venv\Scripts\python.exe"
if not exist "%VPY%" (
    echo    FEHLER: venv-Python nicht gefunden.
    goto :fail
)
echo    venv bereit.
echo.

rem ---------- 5. Abhaengigkeiten ----------
echo [5/6] Installiere Abhaengigkeiten ...
"%VPY%" -m pip install --upgrade pip setuptools wheel --quiet
if exist "%INSTALL_DIR%\requirements.txt" (
    "%VPY%" -m pip install -r "%INSTALL_DIR%\requirements.txt"
) else (
    "%VPY%" -m pip install requests rich beautifulsoup4 PySocks
)
if errorlevel 1 (
    echo    FEHLER: Installation der Abhaengigkeiten fehlgeschlagen.
    goto :fail
)
"%VPY%" -m pip install requests rich beautifulsoup4 PySocks --quiet
echo    Abhaengigkeiten installiert.
echo.

rem ---------- 6. Verifikation + Starter ----------
echo [6/6] Verifiziere Installation ...
pushd "%INSTALL_DIR%"
"%VPY%" poc.py -h >nul 2>&1
if errorlevel 1 (
    echo    WARNUNG: "poc.py -h" meldet einen Fehler. Ausgabe zur Diagnose:
    "%VPY%" poc.py -h
    popd
    goto :fail
)
popd
echo    poc.py laeuft.

> "%INSTALL_DIR%\run.bat" echo @echo off
>> "%INSTALL_DIR%\run.bat" echo chcp 65001 ^>nul
>> "%INSTALL_DIR%\run.bat" echo cd /d "%%~dp0"
>> "%INSTALL_DIR%\run.bat" echo call "%%~dp0.venv\Scripts\activate.bat"
>> "%INSTALL_DIR%\run.bat" echo python "%%~dp0poc.py" %%*
>> "%INSTALL_DIR%\run.bat" echo echo.
>> "%INSTALL_DIR%\run.bat" echo pause

if exist "%TMPPY%" del /q "%TMPPY%" >nul 2>&1
if exist "%TEMP%\python_setup.exe" del /q "%TEMP%\python_setup.exe" >nul 2>&1

echo.
echo ============================================================
echo   FERTIG
echo ============================================================
echo   Ordner:  %INSTALL_DIR%
echo   Start:   run.bat  (im Installationsordner)
echo.
echo   Beispiele:
echo     run.bat -u "https://ziel/" --check
echo     run.bat -u "https://ziel/" --exploit --core-chain -cmd "id"
echo     run.bat -f targets.txt --check --threads 20 --output results.txt
echo.
echo   Hinweis: Fuer winget-Installationen ggf. Terminal neu oeffnen.
echo ============================================================
pause
exit /b 0

rem ================= Hilfsroutinen =================
:find_python
if exist "%TMPPY%" del /q "%TMPPY%" >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -Command "$exe=$null; foreach($c in @('python','python3','py')){ $cmd=Get-Command $c -ErrorAction SilentlyContinue; if($cmd){ $exe=$cmd.Source; break } }; if(-not $exe){ exit 1 }; $ver = & $exe -c 'import sys;print(sys.version_info[0]*100+sys.version_info[1])' 2>$null; if($ver -and [int]$ver -ge 308){ Set-Content -Path '%TMPPY%' -Value $exe -Encoding ASCII; exit 0 }; exit 1"
exit /b %errorlevel%

:refresh_path
powershell -NoProfile -ExecutionPolicy Bypass -Command "$p=[Environment]::GetEnvironmentVariable('Path','Machine')+';'+[Environment]::GetEnvironmentVariable('Path','User'); [Environment]::SetEnvironmentVariable('Path',$p,'Process')"
exit /b 0

:fail
if exist "%TMPPY%" del /q "%TMPPY%" >nul 2>&1
echo.
echo Installation abgebrochen.
pause
exit /b 1