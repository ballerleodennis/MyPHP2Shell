#Requires -Version 5.1
<#
  drupal_recon.ps1 - Sichtung nach gescheiterter LFI-Annahme
  Drupal 7.100 + CiviCRM, offene Registrierung, update.php gesperrt
#>
param([string]$Base='https://ufcw464a.org/')
$ErrorActionPreference='Continue'
$T=@('--silent','--show-error','--tlsv1.2','--tls-max','1.2','--ssl-no-revoke','--insecure','--compressed','--max-time','25','--output','NUL','--write-out','%{http_code}')
function Probe([string]$path,[string]$label) {
    $u = if ($path -like 'http*') { $path } else { "$Base$path" }
    $c = & curl.exe @T $u 2>&1
    "{0,-6} {1}" -f $c, $label
}
Write-Host "`n== Dateien / Leftovers ==" -ForegroundColor Cyan
Probe '/README.txt'          'README.txt'
Probe '/INSTALL.txt'         'INSTALL.txt'
Probe '/LICENSE.txt'         'LICENSE.txt'
Probe '/CHANGELOG.txt'       'CHANGELOG.txt'
Probe '/.git/HEAD'           '.git/HEAD'
Probe '/web.config'          'web.config'
Probe '/cron.php'            'cron.php'
Probe '/sites/default/settings.php' 'settings.php (ausgefuehrt)'
Probe '/sites/default/files/backup_migrate/' 'backup_migrate-Verzeichnis'

Write-Host "`n== CiviCRM ==" -ForegroundColor Cyan
Probe '/civicrm/version'                                    'civicrm/version'
Probe '/sites/all/modules/civicrm/civicrm-version.php'      'civicrm-version.php (Standardpfad)'
Probe '/sites/all/modules/contrib/civicrm/civicrm-version.php' 'civicrm-version.php (contrib)'
Probe '/civicrm/ajax/rest?entity=Contact&action=get&json=1&return=id,display_name' 'REST ohne Auth'
Probe '/civicrm/ajax/api4/Contact/get?limit=3'              'APIv4 ohne Auth'
Probe '/civicrm/profile/create?reset=1&gid=1'               'Profil gid=1'
Probe '/civicrm/admin'                                      'civicrm/admin'
Probe '/civicrm/dashboard'                                  'civicrm/dashboard'

Write-Host "`n== Drupal-Oberflaeche ==" -ForegroundColor Cyan
Probe '/admin'                 'admin'
Probe '/admin/config'          'admin/config'
Probe '/user'                  'user'
Probe '/user/password'         'user/password'
Probe '/admin/reports/status'  'reports/status'
foreach ($n in 1..5) { Probe "/user/$n" "user/$n" }