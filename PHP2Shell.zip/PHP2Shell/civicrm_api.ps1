#Requires -Version 5.1
<#
  civicrm_api.ps1 - unauthentifizierte CiviCRM-REST-Sichtung
  Voraussetzung: X-Requested-With, sonst nur CSRF-Warnung
#>
param([string]$Base='https://ufcw464a.org/',[string]$Key='')
$ErrorActionPreference='Continue'
$Out = Join-Path (Get-Location) "civicrm_{0}" -f (Get-Date -Format 'yyyyMMdd_HHmmss')
New-Item -ItemType Directory -Path $Out -Force | Out-Null
$T = @('--silent','--show-error','--tlsv1.2','--tls-max','1.2','--ssl-no-revoke','--insecure','--compressed','--max-time','30')
$X = 'X-Requested-With: XMLHttpRequest'

function Api([string]$entity,[string]$action='get',[string]$extra='') {
    $u = "$Base`civicrm/ajax/rest?entity=$entity&action=$action&json=1&limit=50$extra"
    if ($Key) { $u += "&key=$Key" }
    $r = curl.exe @T -H $X $u 2>&1
    $j = $null; try { $j = $r | ConvertFrom-Json } catch {}
    if ($j -and $j.is_error -eq 1) { return @{ Err = $j.error_message } }
    if ($j) { $r | Set-Content (Join-Path $Out "$entity.json") -Encoding UTF8 }
    return @{ Raw = ($r -join "`n"); Obj = $j }
}

Write-Host "`n== Version ==" -ForegroundColor Cyan
curl.exe @T -s "$Base`sites/all/modules/contrib/civicrm/civicrm-version.php"

Write-Host "`n== Domain (Site-Key, Pfade) ==" -ForegroundColor Cyan
$d = Api 'Domain'
if ($d.Err) { Write-Host "FEHLER: $($d.Err)" -ForegroundColor Yellow } else { $d.Raw }

Write-Host "`n== UFMatch (Drupal-uid <-> Contact) ==" -ForegroundColor Cyan
$u = Api 'UFMatch'
if ($u.Err) { Write-Host "FEHLER: $($u.Err)" -ForegroundColor Yellow }
elseif ($u.Obj.values) { $u.Obj.values | Select-Object uf_id,contact_id | Format-Table -AutoSize }

Write-Host "`n== Contacts ==" -ForegroundColor Cyan
$c = Api 'Contact' 'get' '&return=id,display_name,contact_type,organization_name'
if ($c.Err) { Write-Host "FEHLER: $($c.Err)" -ForegroundColor Yellow }
elseif ($c.Obj.values) { Write-Host ("{0} Datensaetze" -f $c.Obj.count); $c.Obj.values | Select-Object -First 20 id,display_name,contact_type | Format-Table -AutoSize }

Write-Host "`n== E-Mails ==" -ForegroundColor Cyan
$e = Api 'Email' 'get' '&return=contact_id,email'
if ($e.Err) { Write-Host "FEHLER: $($e.Err)" -ForegroundColor Yellow }
elseif ($e.Obj.values) { $e.Obj.values | Select-Object -First 30 contact_id,email | Format-Table -AutoSize }

Write-Host "`n== Weitere Entities ==" -ForegroundColor Cyan
foreach ($ent in 'GroupContact','Membership','Contribution','Website','Phone','OptionValue','Setting','File') {
    $x = Api $ent
    if ($x.Err) { "{0,-14} {1}" -f $ent, $x.Err }
    elseif ($x.Obj) { "{0,-14} count={1}" -f $ent, $x.Obj.count }
}

Write-Host "`n== civicrm/file Download-Test ==" -ForegroundColor Cyan
foreach ($id in 1..15) {
    $c2 = curl.exe @T -o NUL -w "%{http_code} %{size_download}" "$Base`civicrm/file?reset=1&id=$id"
    if ($c2 -notmatch '^404') { "id=$id -> $c2" }
}

Write-Host "`n== Pfad-Korrektur: Multisite ==" -ForegroundColor Cyan
foreach ($p in 'sites/ufcw464a.org/settings.php','sites/ufcw464a.org/files/','sites/ufcw464a.org/files/backup_migrate/','.git/config','.git/index','.htaccess','sites/all/modules/contrib/civicrm/CRM/Utils/Version.php') {
    $c3 = curl.exe @T -o NUL -w "%{http_code}" "$Base$p"
    "{0,-6} {1}" -f $c3, $p
}
Write-Host "`nDaten in: $Out" -ForegroundColor DarkGray