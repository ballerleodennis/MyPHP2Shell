#Requires -Version 5.1
<#
  civicrm2.ps1 - Session-fest, Version, settings.php-Backups, dann API-Sweep
#>
param([string]$Base='https://ufcw464a.org/')
$ErrorActionPreference='Continue'
$Out = Join-Path (Get-Location) ("civicrm_" + (Get-Date -Format 'yyyyMMdd_HHmmss'))
New-Item -ItemType Directory -Path $Out -Force | Out-Null
$Jar = Join-Path $Out 'jar.txt'
$T = @('--silent','--show-error','--tlsv1.2','--tls-max','1.2','--ssl-no-revoke','--insecure','--compressed','--max-time','30','--cookie-jar',$Jar,'--cookie',$Jar)
$X = 'X-Requested-With: XMLHttpRequest'

function Get2([string]$path) { (curl.exe @T -w "`n%{http_code}" "$Base$path" 2>&1) -join "`n" }

Write-Host "`n== CiviCRM-Version (version.xml) ==" -ForegroundColor Cyan
$v = Get2 'sites/all/modules/contrib/civicrm/xml/version.xml'
if ($v -match '<version>([^<]+)</version>') { Write-Host ("VERSION: {0}" -f $Matches[1]) -ForegroundColor Green } else { Write-Host 'version.xml nicht lesbar' -ForegroundColor Yellow }

Write-Host "`n== settings.php-Backups ==" -ForegroundColor Cyan
foreach ($s in 'settings.php.bak','settings.php~','settings.php.orig','settings.php.save','settings.php.txt','settings.php.old','settings.php.dist','.settings.php.swp','settings.php.swp') {
    $c = curl.exe @T -o (Join-Path $Out ($s -replace '[^a-z0-9\.]','_')) -w "%{http_code} %{size_download}" "$Base`sites/ufcw464a.org/$s"
    if ($c -notmatch '^404') { "{0,-28} {1}" -f $s, $c }
}

Write-Host "`n== Session etablieren ==" -ForegroundColor Cyan
curl.exe @T -o NUL -w "Startseite: %{http_code}`n" $Base
Start-Sleep -Milliseconds 500

function Api([string]$entity,[string]$extra='') {
    $r = curl.exe @T -H $X "$Base`civicrm/ajax/rest?entity=$entity&action=get&json=1&limit=50$extra" 2>&1
    $j = $null; try { $j = ($r -join "`n") | ConvertFrom-Json } catch {}
    if ($j -and $j.is_error -eq 1) { return @{ Err = $j.error_message } }
    if ($j -and $j.values) { $r | Set-Content (Join-Path $Out "$entity.json") -Encoding UTF8 }
    @{ Raw = ($r -join "`n"); Obj = $j }
}

Write-Host "`n== Entities ==" -ForegroundColor Cyan
foreach ($ent in 'Contact','Email','Phone','Website','Group','GroupContact','OptionValue','Setting','Domain','UFMatch','Membership','Contribution','File','CustomField','Tag') {
    $x = Api $ent
    if ($x.Err) { "{0,-14} {1}" -f $ent, $x.Err }
    elseif ($x.Obj) { "{0,-14} count={1}" -f $ent, $x.Obj.count }
    else { "{0,-14} unklar" -f $ent }
    Start-Sleep -Milliseconds 450
}

Write-Host "`n== Contact-Felder vollstaendig (erste 5) ==" -ForegroundColor Cyan
$c = Api 'Contact' '&return=id,display_name,contact_type,organization_name,nick_name'
if ($c.Obj.values) { $c.Obj.values | Select-Object -First 5 | Format-List }

Write-Host "`n== E-Mails (erste 20) ==" -ForegroundColor Cyan
$e = Api 'Email'
if ($e.Obj.values) { $e.Obj.values | Select-Object -First 20 | Format-List }

Write-Host "`nDaten in: $Out" -ForegroundColor DarkGray